A Pen created at CodePen.io. You can find this one at https://codepen.io/sp-sabri/pen/jBBKEp.

 Touch enabled jQuery plugin that lets you create beautiful responsive carousel slider with Vertical Thumbnails.
